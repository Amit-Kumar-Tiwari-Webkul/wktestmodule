Test module to justify email subject translations issue
