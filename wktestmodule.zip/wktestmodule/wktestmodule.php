<?php
if (!defined('_PS_VERSION_'))
    exit;

class WktestModule extends Module
{
    public function __construct()
    {
        $this->name = 'wktestmodule';
        $this->tab = 'administration';
        $this->version = '1.0.0';
        $this->author = 'Webkul';
        $this->ps_versions_compliancy = array('min' => '1.7.4.0', 'max' => _PS_VERSION_);
        parent::__construct();
        $this->displayName = $this->l('Email Translations');
        $this->description = $this->l('Test module');
    }

    public function sendEmail()
    {
        Mail::Send(
            $this->context->language->id, 
            'wk_test_module',
            Mail::l('Testing for bug'), 
            array(
                'tpl_var_1' => "Tpl Variable 1",
                'tpl_var_2' => "Tpl Variable 2"
            ),
            'tomail',
            null,
            null,
            null,
            null,
            null,
            _PS_MODULE_DIR_.'wktestmodule/mails/'
        );
    }
}
